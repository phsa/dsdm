package br.ufc.crateus.praticaiii;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

class UserHolder extends RecyclerView.ViewHolder {

    private TextView usernameView;
    private TextView passwordView;


    public UserHolder(@NonNull View itemView) {
        super(itemView);

        usernameView = itemView.findViewById(R.id.username_view);
//        passwordView = itemView.findViewById(R.id.password_view);
    }

    public void setUser(String user) {
        usernameView.setText(user);
//        passwordView.setText(user.getPassword());
    }
}
