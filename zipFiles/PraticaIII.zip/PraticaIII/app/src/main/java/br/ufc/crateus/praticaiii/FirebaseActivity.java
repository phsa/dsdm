package br.ufc.crateus.praticaiii;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class FirebaseActivity extends AppCompatActivity {

    private List<String> users = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firebase);

        FirebaseDatabase database = FirebaseDatabase.getInstance("https://mobile-c1ce5.firebaseio.com/");
        final DatabaseReference myRef = database.getReference("users");

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                Log.d("DebugginFirebase", "onDataChange: ");
                Iterable<DataSnapshot> children = dataSnapshot.getChildren();
                for(DataSnapshot data : children) {
                    users.add("" + data.getValue());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(FirebaseActivity.this, "Erro.", Toast.LENGTH_SHORT).show();
            }});

        RecyclerView firebaseUsers = findViewById(R.id.firebase_users_list);
        final UserAdapter adapter = new UserAdapter(new ArrayList<String>());
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        firebaseUsers.setAdapter(adapter);
        firebaseUsers.setLayoutManager(layoutManager);

        Button sendButton = findViewById(R.id.send_button);
        final Button listButton = findViewById(R.id.list_button);
        final Button nextButton = findViewById(R.id.next_button);

        final SharedPreferences preferences = getSharedPreferences("app", Context.MODE_PRIVATE);

        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                for (int i = 1; i < 6; i++) {
                    myRef.push().setValue(new User(preferences.getString("user" + i, ""),
                                                    preferences.getString("password" + i, "")));
                }
                listButton.setEnabled(true);
            }
        });

        listButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                adapter.insertUsers(users);
                nextButton.setEnabled(true);
            }
        });

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(FirebaseActivity.this, MapsActivity.class));
            }
        });
    }
}
