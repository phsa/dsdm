package br.ufc.crateus.praticaiii;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserHolder> {

    private List<String> users;

    public UserAdapter(List<String> users) {
        this.users = users;
    }

    @NonNull
    @Override
    public UserHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new UserHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.user_line, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull UserHolder holder, int position) {
        holder.setUser(users.get(position));
    }

    @Override
    public int getItemCount() {
        return users.size();
    }

    public void insertUser(User user) {
        users.add(user.toString());
        notifyItemInserted(getItemCount());
    }

    public void insertUsers(List<String> users) {
        this.users.clear();
        this.users.addAll(users);
        notifyDataSetChanged();
    }
}
