package br.ufc.crateus.dsdm.sockets;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class App {

	public static void main(String[] args) {
		
		try {
			ServerSocket server = new ServerSocket(8080);
			
			while(true) {
				Socket socket = server.accept();
				
				DataInputStream dataIn = new DataInputStream(socket.getInputStream());
				DataOutputStream dataOut = new DataOutputStream(socket.getOutputStream());
				
				String result = dataIn.readUTF();
				System.out.println(result);
				
				dataIn.close();
				dataOut.close();
				socket.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
