package br.ufc.crateus.restexercise.rest.service;

import java.util.List;

import br.ufc.crateus.restexercise.model.User;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface UserRESTService {

    String PATH = "/users";

    @GET(PATH)
    Call<List<User>> getUsers();

    @GET(PATH + "/{id}")
    Call<User> getUser(@Path("id") Integer id);

    @POST(PATH)
    Call<Void> addUser(@Body User user);

    @PUT(PATH)
    Call<Void> updateUser(@Body User user);

    @DELETE(PATH + "/{id}")
    Call<Void> deleteUser(@Path("id") Integer id);
}
