package br.ufc.crateus.restexercise.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import java.util.List;

import br.ufc.crateus.restexercise.R;
import br.ufc.crateus.restexercise.rest.service.UserRESTService;
import br.ufc.crateus.restexercise.model.User;
import br.ufc.crateus.restexercise.rest.RetrofitClientInstance;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "TestingRetrofit";

    private UserRESTService service;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        service = RetrofitClientInstance.getRESTService(UserRESTService.class);

//        Call<List<User>> usersCall = service.getUsers();
//        usersCall.enqueue(new Callback<List<User>>() {
//            @Override
//            public void onResponse(Call<List<User>> call, Response<List<User>> response) {
//                for (User user : response.body()) {
//                    Log.d(TAG, "onResponse: " + user.toString());
//                }
//            }
//
//            @Override
//            public void onFailure(Call<List<User>> call, Throwable t) {
//
//            }
//        });



        Call<Void> addUserCall = service.addUser(new User(-1, "John Smith", "js"));
        addUserCall.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                Log.d(TAG, "onResponse: User added successfully with ID = " + response.body());
//                Call<User> userCall = service.getUser(response.body());
//                userCall.enqueue(new Callback<User>() {
//                    @Override
//                    public void onResponse(Call<User> call, Response<User> response) {
//                        Log.d(TAG, "onResponse: " + response.body().toString());
//                    }
//
//                    @Override
//                    public void onFailure(Call<User> call, Throwable t) {
//
//                    }
//                });
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {

            }
        });

    }
}
