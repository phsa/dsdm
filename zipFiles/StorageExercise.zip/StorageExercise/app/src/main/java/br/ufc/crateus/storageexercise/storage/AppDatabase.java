package br.ufc.crateus.storageexercise.storage;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import br.ufc.crateus.storageexercise.model.Car;
import br.ufc.crateus.storageexercise.model.User;

@Database(exportSchema = false, entities = {User.class, Car.class}, version = 2)
public abstract class AppDatabase extends RoomDatabase {
    public abstract UserDAO userDao();
    public abstract CarDAO carDao();
}
