package br.ufc.crateus.storageexercise.storage;


import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import br.ufc.crateus.storageexercise.model.Car;

@Dao
public interface CarDAO {

    @Query("SELECT * FROM Car")
    List<Car> getAll();

    @Query("SELECT * FROM Car WHERE id = :id")
    Car getById(int id);

    @Insert
    void addCar(Car car);

    @Update
    void updateCar(Car car);

    @Delete
    void deleteCar(Car car);
}
