package br.ufc.crateus.storageexercise.view;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import br.ufc.crateus.storageexercise.R;
import br.ufc.crateus.storageexercise.model.Car;

public class CarAdapter extends RecyclerView.Adapter<CarHolder> {

    private List<Car> cars;

    public CarAdapter(List<Car> cars) {
        this.cars = cars;
    }

    @NonNull
    @Override
    public CarHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new CarHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.car_line, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull CarHolder holder, int position) {
        holder.setCarInfo(cars.get(position));
    }

    @Override
    public int getItemCount() {
        return cars.size();
    }

    public void insertCars(List<Car> cars) {
        this.cars = cars;
        notifyDataSetChanged();
    }
}
