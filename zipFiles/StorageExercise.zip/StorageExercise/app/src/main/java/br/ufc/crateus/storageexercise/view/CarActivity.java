package br.ufc.crateus.storageexercise.view;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import br.ufc.crateus.storageexercise.R;
import br.ufc.crateus.storageexercise.model.Car;
import br.ufc.crateus.storageexercise.storage.CarDAO;
import br.ufc.crateus.storageexercise.storage.DatabaseClient;

public class CarActivity extends AppCompatActivity {

    private CarDAO carDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car);

        RecyclerView cars = findViewById(R.id.car_list);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        CarAdapter adapter = new CarAdapter(new ArrayList<Car>());
        cars.setLayoutManager(layoutManager);
        cars.setAdapter(adapter);

        carDAO = DatabaseClient.getInstance(this).carDao();

        Button button = findViewById(R.id.add_button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                carDAO.addCar(new Car("FIAT", "Uno", 2001));
            }
        });
    }
}
