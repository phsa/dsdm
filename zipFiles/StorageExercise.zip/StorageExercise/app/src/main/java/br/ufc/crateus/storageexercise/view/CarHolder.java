package br.ufc.crateus.storageexercise.view;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import br.ufc.crateus.storageexercise.R;
import br.ufc.crateus.storageexercise.model.Car;

public class CarHolder extends RecyclerView.ViewHolder {

    private TextView brandView;
    private TextView modelView;
    private TextView yearView;

    public CarHolder(@NonNull View itemView) {
        super(itemView);

        brandView = itemView.findViewById(R.id.brand_view);
        modelView = itemView.findViewById(R.id.model_view);
        yearView = itemView.findViewById(R.id.year_view);
    }

    public void setCarInfo(Car car) {
        brandView.setText(car.getBrand());
        modelView.setText(car.getModel());
        yearView.setText(String.valueOf(car.getYear()));
    }
}
