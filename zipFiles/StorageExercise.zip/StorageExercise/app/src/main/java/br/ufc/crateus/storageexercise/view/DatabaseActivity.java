package br.ufc.crateus.storageexercise.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import br.ufc.crateus.storageexercise.R;
import br.ufc.crateus.storageexercise.model.User;
import br.ufc.crateus.storageexercise.storage.DatabaseClient;
import br.ufc.crateus.storageexercise.storage.UserDAO;

public class DatabaseActivity extends AppCompatActivity {

    UserDAO usersDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);

        usersDAO = DatabaseClient.getInstance(this).userDao();

        usersDAO.insert(new User("João", "Silva"));

        Log.d("MainActivity", "onCreate: " + usersDAO.getAll());
    }
}
