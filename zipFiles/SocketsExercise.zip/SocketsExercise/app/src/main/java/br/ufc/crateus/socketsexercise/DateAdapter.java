package br.ufc.crateus.socketsexercise;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DateAdapter extends RecyclerView.Adapter<DateHolder> {

    private List<String> dates;

    public DateAdapter(List<String> dates) {
        this.dates = dates;
    }

    @NonNull
    @Override
    public DateHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new DateHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.date_holder, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull DateHolder holder, int position) {
        holder.setDateView(dates.get(position));
    }

    @Override
    public int getItemCount() {
        return dates.size();
    }

    public void insertItem(String date) {
        dates.add(date);
        notifyItemChanged(getItemCount());
    }
}
