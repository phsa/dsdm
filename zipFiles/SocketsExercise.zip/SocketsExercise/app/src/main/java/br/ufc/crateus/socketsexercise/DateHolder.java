package br.ufc.crateus.socketsexercise;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class DateHolder extends RecyclerView.ViewHolder {

    private TextView dateView;

    public DateHolder(@NonNull View itemView) {
        super(itemView);

        dateView = itemView.findViewById(R.id.dateView);
    }

    public void setDateView(String text) {
        dateView.setText(text);
    }
}
