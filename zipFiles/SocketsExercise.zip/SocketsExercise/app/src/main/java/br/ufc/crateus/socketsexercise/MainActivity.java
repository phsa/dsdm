package br.ufc.crateus.socketsexercise;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {

    private EditText text_input_field;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().hide();

        Button button = findViewById(R.id.button);
        text_input_field = findViewById(R.id.text_input_field);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        final String HOST = "192.168.0.114";
                        String text = text_input_field.getText().toString();

                        try {
                            Socket socket = new Socket(HOST, 50000);

                            DataInputStream dataIn = new DataInputStream(socket.getInputStream());
                            DataOutputStream dataOut = new DataOutputStream(socket.getOutputStream());

                            dataOut.writeUTF(text);

                            dataIn.close();
                            dataOut.close();
                            socket.close();

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
        });
    }
}
