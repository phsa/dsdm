package br.ufc.crateus.socketsexercise;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private final String HOST = "192.168.0.114";

    private DateAdapter datesAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().hide();

        Button button = findViewById(R.id.button);

        RecyclerView datesList = findViewById(R.id.dates_list);
        LinearLayoutManager lManager = new LinearLayoutManager(this);
        datesList.setLayoutManager(lManager);
        datesAdapter = new DateAdapter(new ArrayList<String>());
        datesList.setAdapter(datesAdapter);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {

                        try {
                            Socket socket = new Socket(HOST, 60000);

                            DataInputStream dataIn = new DataInputStream(socket.getInputStream());

                            final long timestamp = dataIn.readLong();

                            final DateFormat formatter = new SimpleDateFormat("HH:mm:ss dd/MM/yyyy", Locale.getDefault());

                            Log.d("TestingTimeStamp", "run: " + timestamp);

                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    String formattedDateStr = formatter.format(new Date(timestamp));
                                    Log.d("TestingTimeStamp", "run: " + formattedDateStr);
                                    datesAdapter.insertItem(formattedDateStr);
                                }
                            });

                            dataIn.close();
                            socket.close();

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
        });
    }
}
