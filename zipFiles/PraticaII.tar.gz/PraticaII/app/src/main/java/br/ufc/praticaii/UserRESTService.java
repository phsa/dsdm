package br.ufc.praticaii;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface UserRESTService {

    String PATH = "/api/users";

    @GET(PATH)
    Call<List<User>> getUsers();

}
