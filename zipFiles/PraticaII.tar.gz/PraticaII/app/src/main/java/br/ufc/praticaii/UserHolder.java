package br.ufc.praticaii;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

class UserHolder extends RecyclerView.ViewHolder {

    private TextView nameView;
    private TextView usernameView;

    public UserHolder(@NonNull View itemView) {
        super(itemView);

        nameView = itemView.findViewById(R.id.name_view);
        usernameView = itemView.findViewById(R.id.username_view);
    }

    public void setUser(User user) {
        nameView.setText(user.getName());
        usernameView.setText(user.getUsername());
    }
}
