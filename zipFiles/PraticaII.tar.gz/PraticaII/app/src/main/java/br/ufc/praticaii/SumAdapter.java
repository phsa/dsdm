package br.ufc.praticaii;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class SumAdapter extends RecyclerView.Adapter<SumHolder> {

    private List<String> sums;

    public SumAdapter() {
        sums = new ArrayList<>();
    }

    @NonNull
    @Override
    public SumHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new SumHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.sum_line, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull SumHolder holder, int position) {
        holder.setSum(sums.get(position));
    }

    @Override
    public int getItemCount() {
        return sums.size();
    }

    public void insertSum(String sum) {
        sums.add(sum);
        notifyItemInserted(getItemCount());
    }
}
