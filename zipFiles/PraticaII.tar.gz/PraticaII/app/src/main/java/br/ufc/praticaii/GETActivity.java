package br.ufc.praticaii;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GETActivity extends AppCompatActivity {

    private Button button;
    private Button nextButton;
    private UserRESTService service;
    private RecyclerView users;
    private UserAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get);

        button = findViewById(R.id.button);
        nextButton = findViewById(R.id.get_next_button);
        nextButton.setEnabled(false);

        service = RetrofitFactory.getRESTAPI(UserRESTService.class);

        users = findViewById(R.id.users);
        adapter = new UserAdapter();
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);

        users.setLayoutManager(layoutManager);
        users.setAdapter(adapter);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                service.getUsers().enqueue(new Callback<List<User>>() {
                    @Override
                    public void onResponse(Call<List<User>> call, Response<List<User>> response) {
                        for (final User user: response.body())
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    adapter.insertUser(user);
                                }
                            });
                    }

                    @Override
                    public void onFailure(Call<List<User>> call, Throwable t) {

                    }
                });
            }
        });


        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                startActivity(new Intent(GETActivity.this, POSTActivity.class));
                finish();
            }
        });

    }
}
