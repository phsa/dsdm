package br.ufc.praticaii;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ConnectException;
import java.net.Socket;

public class SocketActivity extends AppCompatActivity {

    private final String HOST = "10.42.0.1";

    private Button next;
    private RecyclerView numbers;
    private SumAdapter adapter;

    private int counter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_socket);

        next = findViewById(R.id.socket_next_button);
//        next.setEnabled(false);

        numbers = findViewById(R.id.recycler_numbers);
        adapter = new SumAdapter();
        numbers.setAdapter(adapter);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        numbers.setLayoutManager(layoutManager);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(SocketActivity.this, GETActivity.class));
            }
        });

        final FloatingActionButton fabNumbers = findViewById(R.id.fab_numbers);
        fabNumbers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Socket socket = new Socket(HOST, 60000);
                            DataOutputStream OK = new DataOutputStream(socket.getOutputStream());
                            DataInputStream number = new DataInputStream(socket.getInputStream());

                            StringBuilder line = new StringBuilder();

                            OK.writeUTF("OK");
                            int firstNumber = number.readInt();

                            OK.writeUTF("OK");
                            int secondNumber = number.readInt();

                            OK.writeUTF("OK");
                            int thirdNumber = number.readInt();

                            Log.d("TestServerAccess", "run: Conectou e pegou os números " + firstNumber);

                            line.append(firstNumber);
                            line.append(" + ");

                            line.append(secondNumber);
                            line.append(" + ");

                            line.append(thirdNumber);
                            line.append(" = ");

                            line.append(firstNumber + secondNumber + thirdNumber);

                            updateSums(line.toString());


                            OK.close();
                            number.close();
                            socket.close();

                            counter++;
                            if (counter >= 5) {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        fabNumbers.setEnabled(false);
                                        next.setEnabled(true);
                                    }
                                });
                            }
                        } catch (ConnectException e) {
                            Log.d("TestServerAccess", "run: Servidor indisponível");
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
        });
    }

    private void updateSums(final String sum) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                adapter.insertSum(sum);
            }
        });
    }
}
