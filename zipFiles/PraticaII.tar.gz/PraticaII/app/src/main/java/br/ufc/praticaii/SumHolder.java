package br.ufc.praticaii;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class SumHolder extends RecyclerView.ViewHolder {

    private TextView sumView;

    public SumHolder(@NonNull View itemView) {
        super(itemView);
        sumView = itemView.findViewById(R.id.sum_view);
    }

    public void setSum(String sum) {
        this.sumView.setText(sum);
    }
}
