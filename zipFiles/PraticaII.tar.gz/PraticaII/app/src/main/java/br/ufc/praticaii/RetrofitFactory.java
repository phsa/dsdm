package br.ufc.praticaii;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitFactory {

    private static Retrofit retrofit;

    public static <T> T getRESTAPI(Class<T> clazz) {
        if (retrofit == null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl("https://almada-app-server.herokuapp.com")
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit.create(clazz);
    }

}
