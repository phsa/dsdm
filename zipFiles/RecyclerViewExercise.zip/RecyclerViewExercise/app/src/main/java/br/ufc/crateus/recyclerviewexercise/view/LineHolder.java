package br.ufc.crateus.recyclerviewexercise.view;

import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import br.ufc.crateus.recyclerviewexercise.R;

public class LineHolder extends RecyclerView.ViewHolder {

    public TextView nameView;
    public TextView ageView;
    public TextView cityView;
    public ImageButton moreButton;
    public ImageButton deleteButton;

    public LineHolder(View itemView) {
        super(itemView);
        nameView = itemView.findViewById(R.id.name_view);
        ageView = itemView.findViewById(R.id.age_view);
        cityView = itemView.findViewById(R.id.city_view);
        moreButton = itemView.findViewById(R.id.recycler_more);
        deleteButton = itemView.findViewById(R.id.recycler_delete);
    }
}