package br.ufc.crateus.recyclerviewexercise.view;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.EditText;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

import br.ufc.crateus.recyclerviewexercise.R;
import br.ufc.crateus.recyclerviewexercise.model.UserModel;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private LineAdapter mAdapter;
    private EditText nameInput;
    private EditText ageInput;
    private EditText cityInput;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameInput = findViewById(R.id.name_input);
        ageInput = findViewById(R.id.age_input);
        cityInput = findViewById(R.id.city_input);

        recyclerView = findViewById(R.id.recyclerView);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        mAdapter = new LineAdapter(new ArrayList(0));
        recyclerView.setAdapter(mAdapter);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(view -> insertItem());
    }

    public void insertItem() {
        UserModel model = new UserModel();
        model.setName(nameInput.getText().toString());
        model.setAge(Integer.parseInt(ageInput.getText().toString()));
        model.setCity(cityInput.getText().toString());
        mAdapter.insertItem(model);
        clear();
    }

    public void clear() {
        nameInput.setText("");
        ageInput.setText("");
        cityInput.setText("");
    }
}
