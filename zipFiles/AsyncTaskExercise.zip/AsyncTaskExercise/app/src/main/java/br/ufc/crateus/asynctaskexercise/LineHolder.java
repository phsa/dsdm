package br.ufc.crateus.asynctaskexercise;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class LineHolder extends RecyclerView.ViewHolder {

    private TextView stringView;

    public LineHolder(@NonNull View itemView) {
        super(itemView);

        stringView = itemView.findViewById(R.id.string_view);
    }

    public void setStringView(String s) {
        stringView.setText(s);
    }
}
