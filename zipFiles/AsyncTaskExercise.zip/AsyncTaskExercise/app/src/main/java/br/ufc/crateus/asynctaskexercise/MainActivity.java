package br.ufc.crateus.asynctaskexercise;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

//    private TextView thResult;
//    private int i = 0;
//    private Handler handler;
//    private ImageView imageView;

    private ProgressDialog p;
    private Button button;
    private RecyclerView recyclerView;
    private DataAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.button);
        recyclerView = findViewById(R.id.string_list);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new DataAdapter(new ArrayList<String>());
        recyclerView.setAdapter(adapter);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AsyncTaskExample().execute("https://jsonplaceholder.typicode.com/users");
            }
        });



//        thResult = findViewById(R.id.th_result);
//        threadExamples();
    }

//    private void threadExamples() {
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                while(true) {
//                    runOnUiThread(new Runnable() {
//                        @Override
//                        public void run() {
//                            thResult.setText("" + i++);
//                        }
//                    });
//
//                    try {
//                        Thread.sleep(1000);
//                    } catch (InterruptedException e) {
//                        e.printStackTrace();
//                    }
//                }
//            }
//        }).start();
//
//        handler = new Handler();
//        handler.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                Toast.makeText(MainActivity.this, "Contando...", Toast.LENGTH_SHORT).show();
//                handler.postDelayed(this, 5000);
//            }
//        }, 1500);
//    }

    private static String convertInputStreamToString(InputStream inputStream) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        String line = "";
        String result = "";
        while ((line = bufferedReader.readLine()) != null) {
            result += line;
        }

        inputStream.close();
        return result;
    }

    private class AsyncTaskExample extends AsyncTask<String, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            p = new ProgressDialog(MainActivity.this);
            p.setMessage("Please wait...It is downloading");
            p.setIndeterminate(false);
            p.setCancelable(false);
            p.show();
        }

        @Override
        protected String doInBackground(String... strings) {
//            Bitmap bmImg = null;
            try {
                URL imageUrl = new URL(strings[0]);
                HttpURLConnection conn = (HttpURLConnection) imageUrl.openConnection();
                conn.setDoInput(true);
                conn.connect();
                InputStream is = conn.getInputStream();
                return convertInputStreamToString(is);
//                BitmapFactory.Options options = new BitmapFactory.Options();
//                options.inPreferredConfig = Bitmap.Config.RGB_565;
//                bmImg = BitmapFactory.decodeStream(is, null, options);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String json) {
            super.onPostExecute(json);
            try {
                if (json.charAt(0) == '[') {
                    JSONArray array = new JSONArray(json);
                    for (int i = 0; i < array.length(); i++) {
                        adapter.insertItem(array.getJSONObject(i).getString("name"));
                    }
                } else {
                    adapter.insertItem(new JSONObject(json).getString("name"));
                }
            } catch (JSONException e) {
                Toast.makeText(MainActivity.this, "Acesso aos dados falhou.", Toast.LENGTH_SHORT).show();
            }
            p.hide();
//            if(imageView!=null) {
//                p.hide();
//                imageView.setImageBitmap(bitmap);
//            }else {
//                p.show();
//            }
        }
    }
}
