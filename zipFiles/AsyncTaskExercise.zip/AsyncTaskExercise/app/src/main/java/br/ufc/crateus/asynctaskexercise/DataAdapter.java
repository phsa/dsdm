package br.ufc.crateus.asynctaskexercise;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DataAdapter extends RecyclerView.Adapter<LineHolder> {

    private List<String> strings;

    public DataAdapter(List<String> strings) {
        this.strings = strings;
    }


    @NonNull
    @Override
    public LineHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new LineHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.line_layout, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull LineHolder holder, int position) {
        holder.setStringView(strings.get(position));
    }

    @Override
    public int getItemCount() {
        return strings.size();
    }



    public void insertItem(String s) {
        strings.add(s);
        notifyItemInserted(getItemCount());
    }
}
